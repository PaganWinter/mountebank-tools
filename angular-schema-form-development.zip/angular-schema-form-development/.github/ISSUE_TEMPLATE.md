<!-- 
Only include sections relevant to your issue.

If you have not read docs/support.md and followed its guidance you may be ignored or closed without response.

Please use PREVIEW before you submit!!
-->
#### Enhancement
As a user/developer, when I ... I should be able to ...

#### Expected behaviour
I expected ...

#### Actual behaviour
It actually ...

#### Gist/Plunker/Demo
<!--
Here is a demo plunker you can use as a starting point
https://plnkr.co/edit/C9mM5feGGZ0N7povA84G?p=preview
-->
[Description](url)

#### Related issues
This is/maybe related to ...

@json-schema-form/angular-schema-form-lead
