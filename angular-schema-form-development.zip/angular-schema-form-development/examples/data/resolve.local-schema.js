{
  "type": "object",
  "properties": {
    "test": {
      "type": "string"
    }
  }
}
